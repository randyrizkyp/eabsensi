@extends('templates.main')
@section('content')
<style>
    .wfo {
        background: linear-gradient(to right, #D6B7B7, #FAFAD6);
    }

    .wfh {
        background: linear-gradient(to right, #D1F9F5, #FAFAD6);
    }

    .tmk {
        background: linear-gradient(to right, #F6DA8E, #FAFAD6);
    }

    .gbab {
        width: 100px;
        height: 75px;
    }
</style>
<div class="row">
    <div class="col">
        <div class="card">
            <center>
                <div class="card-header">
                    <span class="badge badge-dark">
                        <h3>Pilih Keterangan</h3>
                    </span>
                </div>
                <form action="/absensi/cekAbsen" method="post">
                    @csrf
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item wfo">
                            <h4>Work From Office</h4>
                            <button class="btn btn-success" type="submit" name="wfomasuk" value="true"><img class="gbab"
                                    src="/img/wfomasuk.jpg"><br>Masuk</button>
                            <button class="btn btn-info ml-2" type="submit" name="wfopulang" value="true">
                                <img class="gbab" src="/img/wfopulang.jpeg"><br>Pulang</button>
                        </li>
                        <li class="list-group-item wfh" style="display: none;">
                            <h4>Work From Home</h4>
                            <button class="btn btn-success" type="submit" name="wfhmasuk"><img class="gbab"
                                    src="/img/wfh.png"><br>Absen Masuk</button>
                            <button class="btn btn-info ml-2" type="submit" name="wfhpulang"><img class="gbab"
                                    src="/img/wfh.png"><br>Absen Selesai</button>
                        </li>
                        <li class="list-group-item tmk">
                            <h4>Tidak Masuk Kantor</h4>
                            <button class="btn btn-success " type="submit" name="dinasluar" value="true"><img
                                    class="gbab" src="/img/dl.png"><br>Dinas Luar</button>
                            <button class="btn btn-info" type="submit" name="sakit" value="true"><img class="gbab"
                                    src="/img/sakit.png"><br>Sakit</button><br><br>
                            <button class="btn btn-success" type="submit" name="izin" value="true"><img class="gbab"
                                    src="/img/izin.jpg"><br>Izin</button>
                            <button class="btn btn-info" type="submit" name="cuti" value="true"><img class="gbab"
                                    src="/img/cuti.jpg"><br>Cuti</button><br>
                        </li>
                    </ul>
                </form>
        </div>
        </center>

    </div>
</div>
{{-- notifikasi --}}
@if(session()->has('fail'))
<script>
    Swal.fire({
   position: 'center',
   icon: 'error',
   title: '{{ session("fail") }}',
   showConfirmButton: true
}).then(function(){

document.location.href='/rekapPerorangan';
})
</script>

@endif

{{-- notifikasi --}}
@if(session()->has('gagal'))
<script>
    Swal.fire({
   position: 'center',
   icon: 'error',
   title: '{{ session("gagal") }}',
   showConfirmButton: false,
   timer: 1000
})
</script>

@endif

@endsection