<!DOCTYPE html>
<html>

<head>

    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" type="image/jpg" href="/img/logolampura2.ico">
    <title>Perjalanan Dinas</title>
    <link rel="stylesheet" href="/adminlte/plugins/fontawesome-free/css/all.min.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">


    <script src="https://code.jquery.com/jquery-3.7.0.min.js"
        integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="/js/webcam.js"></script>
    <link rel="stylesheet" href="/package/dist/sweetalert2.min.css">
    <script src="/package/dist/sweetalert2.min.js"></script>


    <!-- Daterange picker -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>


    <style>
        html,
        body {
            width: 100%;
            height: 100%;

            margin: 0;
            padding: 0;
        }


        .tomb {
            width: 50vw;
            font-size: 5vw;
            vertical-align: middle;
            height: 50px;

        }

        #rowcek {
            display: flex;
            box-sizing: border-box;


        }

        .ketpos {
            margin-left: 12vw;
        }


        .pilket {
            margin-left: 11vw;
            margin-top: 5vw;
            width: 70vw;
            font-size: 5vw;
        }


        #isket {
            display: none;
        }

        #fotspt {

            position: relative;
            display: none;
            flex-direction: column;
            justify-content: center;
            align-items: center;


        }

        #loading {
            position: absolute;
            left: 49%;
            bottom: 59%;
            z-index: 999;

        }

        #muatan_gb {}

        .agam {
            font-size: 1.2em;
            /*  margin-top: -13vw;*/
        }

        #tokir {
            justify-content: center;
            z-index: 999;
            margin-top: 10px;



        }
    </style>

</head>

<body>

    <?php 


  $timezone = new DateTimeZone('Asia/Jakarta');
  $date = new DateTime();
  $date->setTimeZone($timezone);
  $jam = $date->format('H');
  $tanggal = $date->format('d');
  $bulan = $date->format('m');
  $tahun = $date->format('Y');
  




     ?>


    <section id="muatan">

        <div class="row">

            <div class="col"><span class="badge badge-success d-flex justify-content-center">
                    <h3>Tanggal Perjalanan Dinas</h3>
                </span></div>
        </div>


        <div class="row mt-4">
            <div class="col">
                <center>
                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="30" fill="currentColor"
                        class="bi bi-calendar-week mr-1" viewBox="0 0 16 16">
                        <path
                            d="M11 6.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-5 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z" />
                        <path
                            d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z" />
                    </svg>
                    <input type="text" name="tglawal" id="tglawal" placeholder="Tgl Berangkat" size="25">
                </center>
            </div>
        </div>

        <div class="col mt-4 d-flex justify-content-center"><span class="badge badge-dark ml-2 mr-2">s/d</span></div>

        <div class="row">
            <div class="col">
                <div class="mt-4 d-flex justify-content-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="30" fill="currentColor"
                        class="bi bi-calendar-week mr-1" viewBox="0 0 16 16">
                        <path
                            d="M11 6.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-5 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z" />
                        <path
                            d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z" />
                    </svg>
                    <input type="text" name="tglkembali" id="tglkembali" placeholder="Tgl Kembali" size="25">
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-center mt-3"><button class="btn btn-primary" name="subtgl"
                id="subtgl">Submit</button></div>


    </section>

    <center>

        <form action="upload_dl.php" method="post" enctype="multipart/form-data">
            <section id="pilfile" style="display: none;">
                <style type="text/css">
                    .image_upload>input {
                        display: none;
                    }
                </style>
                <div class="card"
                    style="width: 80%; background-color: #F8EDED; margin: 10px auto; display: flex; align-items: center; justify-content: center;">
                    <div style="width: 100%; background-color: #A0F9DF">
                        <h5 align="center">Siapkan SPT/SPD Anda</h5>
                    </div>

                    <div>
                        <button type="button" class="btn btn-info my-2" onclick="ShowCam();"><svg
                                xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor"
                                class="bi bi-camera" viewBox="0 0 16 16">
                                <path
                                    d="M15 12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h1.172a3 3 0 0 0 2.12-.879l.83-.828A1 1 0 0 1 6.827 3h2.344a1 1 0 0 1 .707.293l.828.828A3 3 0 0 0 12.828 5H14a1 1 0 0 1 1 1v6zM2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4H2z" />
                                <path
                                    d="M8 11a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5zm0 1a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM3 6.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z" />
                            </svg>&emsp;Ambil Foto</button>
                    </div>
                    <div id="pilgal">

                        <p class="image_upload">
                            <label for="imeg">
                                <a class="btn btn-warning" rel="nofollow"><svg xmlns="http://www.w3.org/2000/svg"
                                        width="25" height="25" fill="currentColor" class="bi bi-card-image"
                                        viewBox="0 0 16 16">
                                        <path d="M6.002 5.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                        <path
                                            d="M1.5 2A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13zm13 1a.5.5 0 0 1 .5.5v6l-3.775-1.947a.5.5 0 0 0-.577.093l-3.71 3.71-2.66-1.772a.5.5 0 0 0-.63.062L1.002 12v.54A.505.505 0 0 1 1 12.5v-9a.5.5 0 0 1 .5-.5h13z" />
                                    </svg>&emsp;Pilih dari Gallery</a>
                            </label>
                            <input type="file" name="imeg" id="imeg">
                        </p>
                        {{--
                        <input type="hidden" name="nip" value="<?= $nip; ?>">
                        <input type="hidden" name="nama" value="<?= $nama; ?>">
                        <input type="hidden" name="fgb" value="" class="fgb">
                        <input type="hidden" name="berangkat" class="berangkat" value="">
                        <input type="hidden" name="kembali" class="kembali" value="">

                        <input type="hidden" name="pangkat" value="<?= $pangkat; ?>">
                        <input type="hidden" name="jabatan" value="<?= $jabatan; ?>">
                        <input type="hidden" name="jenjab" value="<?= $jenjab; ?>">
                        <input type="hidden" name="tpp" value="<?= $tpp; ?>">
                        <input type="hidden" name="tmt_absen" value="<?= $tmt_absen; ?>">

                        <input type="hidden" name="norut" value="<?= $norut; ?>">
                        <input type="hidden" name="jenisdl" value="<?= $jenisdl; ?>">
                        <input type="hidden" name="tujuan" value="<?= $tujuan; ?>">
                        <input type="hidden" name="maksud" value="<?= $maksud; ?>">
                        <input type="hidden" name="pengikut" value="<?= $pengikut; ?>"> --}}

                    </div>


                </div>

            </section>


            <section id="gbsurat" class="my-2" style="display: none; width: 250px; margin: 10px auto;">
                <figure style="display: flex; flex-direction: column; align-items: center;">
                    <span class="nmfile"></span>
                    <img src="" width="250px" height="300px" id="imgView">
                    <button class="btn btn-primary mt-1" type="submit" name="kirim">KIRIM</button>
                </figure>


            </section>
        </form>






        <section id="fotspt" style="display: none;">


            <div id="muatan_gb">
                <div><span class="badge badge-info mt-2 mb-1 ">
                        <h5>Silahkan Foto SPT/SPPD anda</h5>
                    </span></div>
                <div id="my_camera" style="overflow: hidden; width: 90%; height: 480px; margin: auto; ">

                </div>
                <button onclick="take_snapshot()" class="btn btn-primary agam mt-1"><svg
                        xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor"
                        class="bi bi-camera" viewBox="0 0 16 16">
                        <path
                            d="M15 12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h1.172a3 3 0 0 0 2.12-.879l.83-.828A1 1 0 0 1 6.827 3h2.344a1 1 0 0 1 .707.293l.828.828A3 3 0 0 0 12.828 5H14a1 1 0 0 1 1 1v6zM2 4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1.172a2 2 0 0 1-1.414-.586l-.828-.828A2 2 0 0 0 9.172 2H6.828a2 2 0 0 0-1.414.586l-.828.828A2 2 0 0 1 3.172 4H2z" />
                        <path
                            d="M8 11a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5zm0 1a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM3 6.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z" />
                    </svg>&emsp;Ambil Gambar</button>

            </div>



            <div id="loading" style="display: none;">
                <div class="d-flex justify-content-center">
                    <div class="spinner-border text-primary" style="width: 4rem; height: 4rem;" role="status">
                        <span class="sr-only">Loading...</span>
                    </div>
                </div>
            </div>


            <form action="/absensi/uploadDinasLuar" method="post">
                @csrf
                <input type="hidden" name="berangkat" class="berangkat" value="">
                <input type="hidden" name="kembali" class="kembali" value="">
                <input type="hidden" name="jenisdl" value="{{ $jenisdl }}">
                <input type="hidden" name="tujuan" value="{{ $tujuan }}">
                <input type="hidden" name="maksud" value="{{ $maksud }}">
                <input type="hidden" name="pengikut" value="{{ $pengikut }}">
                <input type="hidden" name="data_uri" id="data_uri" value="">




                <div id="tokir" style="display: none;">
                    <button type="submit" name="kirim" class="btn btn-info tomb" id="kirim">Kirim Absen&emsp;<svg
                            xmlns="http://www.w3.org/2000/svg" width="27" height="27" fill="currentColor"
                            class="bi bi-telegram" viewBox="0 0 16 16">
                            <path
                                d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.287 5.906c-.778.324-2.334.994-4.666 2.01-.378.15-.577.298-.595.442-.03.243.275.339.69.47l.175.055c.408.133.958.288 1.243.294.26.006.549-.1.868-.32 2.179-1.471 3.304-2.214 3.374-2.23.05-.012.12-.026.166.016.047.041.042.12.037.141-.03.129-1.227 1.241-1.846 1.817-.193.18-.33.307-.358.336a8.154 8.154 0 0 1-.188.186c-.38.366-.664.64.015 1.088.327.216.589.393.85.571.284.194.568.387.936.629.093.06.183.125.27.187.331.236.63.448.997.414.214-.02.435-.22.547-.82.265-1.417.786-4.486.906-5.751a1.426 1.426 0 0 0-.013-.315.337.337 0 0 0-.114-.217.526.526 0 0 0-.31-.093c-.3.005-.763.166-2.984 1.09z" />
                        </svg></button>
                </div>

            </form>


        </section>
    </center>









    <br><br>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous">
    </script>
    {{-- <script src="/datepicker/js/bootstrap-datepicker.js"></script> --}}
    <script type="text/javascript">
        $( "#tglawal" ).datepicker({
                dateFormat: 'dd M yy',
                autoclose: true,
                todayHighlight: true,
            });
      $("#tglkembali").datepicker({
                dateFormat: 'dd M yy',
                autoclose: true,
                todayHighlight: true,
            });

      $('#subtgl').on('click', function(){

       
          
          var tglawal = $('#tglawal').val();
              tgl1 = new Date(tglawal);

          var tglkembali = $('#tglkembali').val();
              tgl2 = new Date(tglkembali);
          var sel = tgl2-tgl1;
              sel = sel/(24*60*60*1000) ;
              sel = sel + 1 ;
              
          

          if (tglawal == "" || tglkembali == "") {
            Swal.fire({
                position: 'center',
                icon: 'warning',
                title: 'Oops..isi tanggal secara lengkap!',
                showConfirmButton: false,
                timer: 1500
                }).then(function(){

                document.location.reload();})
            
          }else{

              if (sel > 0 && sel <= 30) {

                      Swal.fire({
                      title: 'Anda akan DL selama '+sel+' hari, siapkan bukti SPT/SPPD anda!',
                      text: '',
                      icon: 'warning',
                      showCancelButton: true,
                      confirmButtonColor: '#3085d6',
                      cancelButtonColor: '#d33',
                      confirmButtonText: 'Lanjutkan'
                    }).then((result) => {
                    if (result.isConfirmed){
                        // $('#fotspt').show();
                        $('.berangkat').val(tglawal);
                        $('.kembali').val(tglkembali) ;
                        $('#pilfile').show();
                        
                        
                     }

                    });


              }else if (sel <= 0) {
                  Swal.fire(
                    'uupss!',
                    'Jangan tanggal mundur donk boss!',
                    'error'
                  ).then(function(){
                    document.location.href="dinas_luar.php";

                    });
                
              }else{

                Swal.fire(
                    'uupss!',
                    'input dinas luar maksimal 30 hari',
                    'error'
                  ).then(function(){
                    $('#tglawal').val("");
                    $('#tglkembali').val("");
                    });


              }
        



        }

       



         

          
      })



function ShowCam(){
 
  $('#fotspt').show();
  $('#pilfile').hide();
//   location.href='#my_camera';


   Webcam.attach('#my_camera');
      Webcam.set({
      image_format: 'jpeg',
      jpeg_quality: 100
      });
     

}

  
function take_snapshot() {
    var audio = new Audio("/img/mixkit-camera-shutter-hard-click-1430.mp3");
    audio.play();
    Webcam.snap(function(data_uri) {
    $('#my_camera').html("");
    $('#loading').show();
    document.getElementById('my_camera').innerHTML = '<img id="base64image" src="'+data_uri+'" />';
    $('#data_uri').val(data_uri);
                    $('#loading').hide();
                    $('#tokir').show();
                    $('.agam').css('display', 'none');
                    location.href='#fotspt';
            // $.ajax({
            //     url : '/uploadFoto_DL',
            //     type : 'post',
            //     data : {
            //     _token : "{{ csrf_token() }}",
            //     gambarDL : data_uri
            //     },
            //     cache : false,
            //     success : function(image_return){
            //     if(image_return){
            //         alert(image_return);
            //         // document.getElementById("fgb").value = image_return;
            //         $('#loading').hide();
            //         $('#tokir').show();
                    
            //         $('.agam').css('display', 'none');
            //         location.href='#fotspt';
            //     }
            //     }

            // }); 

    });
    
    

  
}



function SaveSnap(){
    
    
    var file =  document.getElementById("base64image").src;
    
    
    var formdata = new FormData();
    formdata.append("base64image", file);
    var ajax = new XMLHttpRequest();
    ajax.addEventListener("load", function(event) { uploadcomplete(event);}, false);
    ajax.open("POST", "upload_dl.php");
    ajax.send(formdata);
}
function uploadcomplete(event){
  
  var image_return=event.target.responseText;
  if (image_return == "uploads/no_image.png") {
   alert("gagal simpan foto, silahkan ulangi kembali");
    history.go(-1);
    $('#loading').hide();

  }else{

    document.getElementById("fgb").value = image_return;
    $('#loading').hide();
    $('#tokir').show();

     
    $('.agam').css('display', 'none');
    location.href='#fotspt';
    
  }

}


$('#imeg').on('change', function(event){

  var inputFile = $('#imeg').val();
  var pathFile = inputFile.value;
  var ekstensiOk = /(\.jpg|\.jpeg|\.png|\.jfif)$/i;
  var eks = ekstensiOk.exec(inputFile);
  

    if (!ekstensiOk.exec(inputFile)) {
      alert('silahkan upload file .jpg/.jpeg/.png/.jfif');
      return false;
    }else{
      var nmfile = $(this).val();
       $('#pilfile').hide();
       $('#subtgl').hide();
      getURL(this);

    }




})



    function getURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            var filename = $("#imeg").val();
            filename = filename.substring(filename.lastIndexOf('\\') + 1);
           
            reader.onload = function(e) {
                debugger;
                $('.nmfile').html('');
                $('.nmfile').html(filename);
                $('#gbsurat').show();
                $('#imgView').attr('src', e.target.result);
                $('#imgView').hide();
                $('#imgView').fadeIn(500);

            }
            reader.readAsDataURL(input.files[0]);
        }

    }


    </script>

</body>

</html>