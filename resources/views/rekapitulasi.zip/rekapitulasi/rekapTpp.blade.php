@extends('templatesLTE.main')
@section('content')
<?php 
use App\Http\Controllers\RekapitulasiController;
use Illuminate\Support\Carbon;
$rekap = new RekapitulasiController;
?>
<div class="row">
    <div class="col-md-12 p-0 mx-0">
        <div class="mt-4" style="background : linear-gradient(to left ,#8f9103, #f4fad8, #8f9103);">
            <h4 class="text-center pt-2 adopd2">REKAP TPP KEHADIRAN PER BULAN </h4>

            <br>

            <div class="d-flex justify-content-center">
                <form class="form-inline" action="/rekapitulasi/tpp" method="post">
                    @csrf
                    <div class="form-group mb-2 ml-2">
                        <select class="custom-select mr-sm-2" id="carbul" name="bulan">
                            @foreach($namaBulan as $nambul)
                            <option value="{{ $nambul['angka'] }}" {{ $bulan==$nambul['angka'] ? 'selected' : '' }}>
                                {{ $nambul['nama'] }}
                            </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group mb-2 ml-2">
                        <select class="custom-select mr-sm-2" id="carbul" name="tahun">
                            <option {{ $tahun==now()->translatedFormat('Y')-2 ? 'selected' : '' }}>
                                {{ now()->translatedFormat('Y')-2 }}</option>
                            <option {{ $tahun==now()->translatedFormat('Y')-1 ? 'selected' : '' }}>
                                {{ now()->translatedFormat('Y')-1 }}</option>
                            <option {{ $tahun==now()->translatedFormat('Y') ? 'selected' : '' }}>{{
                                now()->translatedFormat('Y') }}</option>
                        </select>
                    </div>
                    <button type="submit" name="carsenrang" class="btn btn-primary mb-2 ml-3">Cari
                        Rekap</button>
                </form>
            </div>
        </div>

    </div>
</div>
<div class="row mt-4">
    <div class="col-md-12">
        <div class="d-flex mb-2">
            <form action="/cetakRekapTPP" method="post" target="_blank">
                @csrf
                <input type="hidden" name="bulan" value="{{ $bulan }}">
                <input type="hidden" name="tahun" value="{{ $tahun }}">
                <button type="submit" class="btn btn-info"><i class="fas fa-file-pdf"></i>&ensp;Download</button>

            </form>
        </div>

        <section>
            <table class="table table-bordered" style="font-size: .7rem" id="rekapBulan">
                <thead>
                    <tr class="bg-info">
                        <th>No</th>
                        <th>Nama / NIP</th>
                        <th>Hadir</th>
                        <th>DL</th>
                        <th>Sakit</th>
                        <th>Cuti</th>
                        <th>Izin</th>
                        <th>TK</th>
                        <th>TAP</th>
                        <th class="text-center">TPP (40%)</th>
                        <th class="text-center">-TPP</th>
                        <th>TPP Kehadiran</th>


                    </tr>

                </thead>
                <tbody>
                    @foreach ($data as $dts)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>
                            {{ $dts->first()->nama }} <br> {{ $dts->first()->nip }} <br> {{ $dts->first()->pangkat }}
                            <br> {{ $dts->first()->jabatan }}
                        </td>
                        <?php $dts = collect($dts); $dts = $dts->sortBy(['tanggal', 'desc']); ?>
                        <td class="text-center">
                            {{ $dts->where('keterangan', 'hadir')->count() }}
                        </td>
                        <td class="text-center">
                            {{ $dts->where('keterangan', 'dinas luar')->count() }}
                        </td>
                        <td class="text-center">
                            {{ $dts->where('keterangan', 'sakit')->count() }}
                        </td>
                        <td class="text-center">
                            {{ $dts->where('keterangan', 'cuti')->count() }}
                        </td>
                        <td class="text-center">
                            {{ $dts->where('keterangan', 'izin')->count() }}
                        </td>
                        <td class="text-center">
                            {{ $dts->where('keterangan', 'tanpa keterangan')->count() }}
                        </td>
                        <td class="text-center">
                            {{ $dts->where('keterangan_p', 'tidak absen')->count() }}
                        </td>
                        <td class="text-center">
                            <?php 
                                $tpp = str_replace('.','', $dts->first()->tpp);
                                $tpph = $tpp * .4;
                                $pengur = $dts->pluck('pengurangan')->sum();
                                $tppkur = $tpph - ($pengur/100 *$tpph );
                                $tpppengur = $pengur/100 * $tpph;
                                
                                ?>
                            Rp.{{ $dts->first()->tpp }} X 40% <br> = Rp.{{ Number_format($tpph, 0,',','.') }}
                        </td>
                        <td class="text-center">

                            {{ $pengur }}% X Rp.{{ Number_format($tpph, 0,',','.') }} <br>
                            = Rp.{{ Number_format($tpppengur, 0,',','.') }}
                        </td>
                        <td>
                            Rp.{{ Number_format($tppkur, 0,',','.') }}
                        </td>
                    </tr>
                    @endforeach

                </tbody>

            </table>
        </section>

    </div>
</div>

@endsection
@push('script')
<script>
    $('#rekapBulan').dataTable();
</script>

@endpush